<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
    <title>INVENTORY MANAGEMENT</title>
    <link rel="stylesheet" type="text/css" href="slidestyle.css">
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@500&display=swap" rel="stylesheet">

</head>
<body>

<header>
    <div class="header">
        
    </div>
</header>

    <div class="main">
        <input type="checkbox" id="chk" aria-hidden="true">


        <div class="signup">
            <form>
                <label for="chk" aria-hidden="true">Sign up</label>
                <input type="text" name="txt" placeholder="Username" required="">
                <input type="email" name="email" placeholder="Email" required="">
                <input type="password" name="pswd" placeholder="Password" required="">
                <button>Sign up</button>
            </form>
        </div>

        <div class="login">
            <form method="POST" action="login.php">
                <?php include('errors.php');?>
                <label for="chk" aria-hidden="true">Login</label>
                 <input type="text" name="username" placeholder="username" required>
                 <input type="password" name="password" placeholder="password" required>
                <button type="submit" class="btn" name="login_user">Login</button>
                <p>
                    Not yet a member? <a href="register.php">Sign up</a>
                </p>
            </form>
        </div>
    </div>
</body>
</html>


       