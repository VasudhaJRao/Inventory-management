<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delivery Details</title>
    <style>
        body {
            font-family:Courier new,cursive;
            margin: 20px;
            background: url('del.jpg') no-repeat center center fixed;
            background-size: cover;
            
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background-color: whitesmoke;
        }
        h1{
            font-size: 3em;
            font-weight: bold;
            text-decoration-line: underline;

        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
        }
        th {
            background-color: lavender;
        }
    </style>
</head>
<body>
    <h1>DELIVERY DETAILS</h1>
    <?php
        // Database connection settings
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "inventory";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $sql = "SELECT d_id, delivery_fee, location, salesdate,quantity, status FROM delivery";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            echo "<table>";
            echo "<tr><th>ID</th><th>Delivery fee</th><th>Address</th><th>Sales Date</th><th>Quantity</th><th>Status</th></tr>";
            // Output data of each row
            while($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["d_id"] . "</td>";
                echo "<td>" . $row["delivery_fee"] . "</td>";
                echo "<td>" . $row["location"] . "</td>";
                echo "<td>" . $row["salesdate"] . "</td>";
                echo "<td>" . $row["quantity"] . "</td>";
                echo "<td>" . $row["status"] . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "0 results";
        }
        $conn->close();
    ?>
</body>
</html>
