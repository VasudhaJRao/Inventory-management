<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Reports</title>
    
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family:  Courier new,cursive;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        h1, h2 {
            text-align: center;
            font-size: 3em;
            font-weight: bold;
            text-decoration-line: underline;
        }

        
        .report-section, .graph-section{

            margin: 20px 0;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }

        th {
            background-color: lavender;
        }
    
 

    </style>
</head>
<body>
    <div class="container">
        <h1>INVENTORY REPORTs</h1>

        <!-- Time Period Filter -->
       

        <!-- Detailed Inventory Report Table -->
        <div class="report-section">
            <h2>Detailed Inventory Report</h2>
            <table id="inventory-report">
                <thead>
                    <tr>
                        <th>Item Name</th>
                        <th>Quantity Sold</th>
                        <th>Stock Remaining</th>
                        <th>Reorder Level</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Dynamic content will be populated here by JavaScript -->
                </tbody>
            </table>
        </div>

        <!-- Sales Graph Section -->
        <div class="graph-section">
            <h2>Sales Graph</h2>
            <canvas id="sales-graph"></canvas>
        </div>
    </div>

    <script src="script.js"></script>
</body>
</html>
