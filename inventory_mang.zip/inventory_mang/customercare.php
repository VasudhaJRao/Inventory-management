<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Support</title>
    <style>
        body {
            font-family: Courier new,cursive;
            font-size: 1em;
        
            margin: 20px;
            background-color: #f8f8f8;
            background: url('pic.jpg') no-repeat center center fixed;
            background-size: cover;

        }
        .support-container {
            background-color: mediumpurple;
            padding: 20px;

            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            margin: auto;
            
            height: 30vh;
        }
        .support-container h1 {
            margin-bottom: 20px;
        }
        .support-container p {
            margin: 10px 0;
        }
        .support-container a {
            color: white;
            text-decoration: none;
        }
        .support-container a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="support-container">
        <h1>Customer Support</h1>
        <p>If you have any questions or need assistance, please contact our customer support:</p>
        <p><strong>Phone Number:</strong> <a href="tel:+1234567890">+1 234 567 890</a></p>
        <p><strong>Email:</strong> <a href="mailto:support@example.com">support@example.com</a></p>
    </div>
</body>
</html>
