
<?php
include 'connect_db.php';

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $product_name = $_POST['product_name'];
    $Price = $_POST['Price'];
    $max_stock = $_POST['max_stock'];
    $quantity_available = $_POST['quantity_available'];
    $quantity_sold = $_POST['quantity_sold'];
    $quantity_remaining = $_POST['quantity_remaining'];
    $sales_date = $_POST['sales_date'];

    // Prepare insert statement
    $sql = "INSERT INTO inventory_mang (product_name, Price, max_stock, quantity_available, quantity_sold, quantity_remaining, sales_date)
            VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Prepare failed: " . htmlspecialchars($conn->error));
    }

    // Bind parameters to the placeholders
    $stmt->bind_param("sdiiiss", $product_name, $Price, $max_stock, $quantity_available, $quantity_sold, $quantity_remaining, $sales_date);
    $executed = $stmt->execute();
    if ($executed) {
        // Redirect to the same page to avoid form resubmission on refresh
        header("Location: add_item.php");
        exit();
    } else {
        echo "Error: " . htmlspecialchars($stmt->error);
    }

    // Close statement
    $stmt->close();
}

// Fetch existing inventory data
$sql = "SELECT product_name, Price, max_stock, quantity_available, quantity_sold, quantity_remaining, sales_date FROM inventory_mang";
$result = $conn->query($sql);

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Item</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>ADD NEW INVENTORY - INVENTORY LEVELS</h1>
        <div class="form-container">

        <form action="add_item.php" method="POST">
            <label for="product_name">Product Name:</label>
            <input type="text" id="product_name" name="product_name" required><br><br>

            <label for="Price">Price:</label>
            <input type="number" step="0.01" id="Price" name="Price" required><br><br>

            <label for="max_stock">Max Stock:</label>
            <input type="number" id="max_stock" name="max_stock" required><br><br>

            <label for="quantity_available">Quantity Available:</label>
            <input type="number" id="quantity_available" name="quantity_available" required><br><br>

            <label for="quantity_sold">Quantity Sold:</label>
            <input type="number" id="quantity_sold" name="quantity_sold" required><br><br>

            <label for="quantity_remaining">Quantity Remaining:</label>
            <input type="number" id="quantity_remaining" name="quantity_remaining" required><br><br>

            <label for="sales_date">Sales Date:</label>
            <input type="date" id="sales_date" name="sales_date" required><br><br>

            <button type="submit">Add Item</button>
        </form>

        <h2>Existing Inventory</h2>
        <table id="inventory-table">
            <thead>
                <tr>
                    <th>Product Name</th>
                    <th>Price</th>
                    <th>Max Stock</th>
                    <th>Quantity Available</th>
                    <th>Quantity Sold</th>
                    <th>Quantity Remaining</th>
                    <th>Sales Date</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>{$row['product_name']}</td>
                                <td>{$row['Price']}</td>
                                <td>{$row['max_stock']}</td>
                                <td>{$row['quantity_available']}</td>
                                <td>{$row['quantity_sold']}</td>
                                <td>{$row['quantity_remaining']}</td>
                                <td>{$row['sales_date']}</td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='7'>No items found</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
