<?php
// Database connection settings
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "inventory";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to fetch warehouse details
$sql = "SELECT warehouse_id, name, location FROM warehouse";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Warehouse Details</title>
    <style>
        body {
            font-family: Courier new,cursive;
            margin: 20px;
            font-size: 1.5em;
            
            background: url('wh.jpg') no-repeat center center fixed;
            background-size: cover;
        }
        table {
            width: 100%;
            background-color: whitesmoke;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        h1{
            font-size: 2em;
            text-decoration-line: underline;
            font-weight: bold;
        }
        table, th, td {
            border: 1px solid #ddd;

        }
        
        th, td {
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: lavender;
        }
    </style>
</head>
<body>
    <h1>WAREHOUSE DETAILS</h1>
    <table>
        <thead>
            <tr>
                <th>Warehouse ID</th>
                <th>Warehouse Name</th>
                <th>Location</th>
                
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                // Output data of each row
                while($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['warehouse_id']}</td>
                            <td>{$row['name']}</td>
                            <td>{$row['location']}</td>
                            
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='4'>No warehouses found</td></tr>";
            }
            ?>
        </tbody>
    </table>
</body>
</html>

<?php
$conn->close();
?>
