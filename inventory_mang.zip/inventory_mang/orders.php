<?php
include 'connect_db.php';
$sql="SELECT 
            orders.orderid, 
            products.p_name, 
            products.price, 
            orders.manufacturer, 
            orders.quantity, 
            (products.price * orders.quantity) AS total_price 
        FROM orders
        JOIN products ON orders.product_id = products.product_id";

        
$result = $conn->query($sql);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders Page</title>
    <style>
        body {
            font-family: Courier new,cursive;
            margin: 20px;
            background: url('op.jpg') no-repeat center center fixed;
            background-size: cover;
            text-align: center;
            
            
            
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            background-color: whitesmoke;
            background-color: black;
            font-size: 1.3em;
        }
        h1{
            font-size: 3em;
            font-weight: bold;
            text-decoration-line: underline;
        }
        table, th, td {
            border: 1px solid #ddd;
            background-color: whitesmoke;
        }
        th, td {
            padding: 12px;
            text-align: left;
        }
        th {
            background-color:lavender;
        }
    </style>
</head>
<body>
    <h1>ORDER DETAILS</h1>
    <table>
        <thead>
            <tr>
                <th>Order ID</th>
                <th>Product Name</th>
                <th>Product Price</th>
                <th>Total Price</th>
                <th>Manufacturer</th>
                <th>Quantity</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                // Output data of each row
                while($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['orderid']}</td>
                            <td>{$row['p_name']}</td>
                            <td>\${$row['price']}</td>
                            <td>\${$row['total_price']}</td>
                            <td>{$row['manufacturer']}</td>
                            <td>{$row['quantity']}</td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='6'>No orders found</td></tr>";
            }
            ?>
        </tbody>
    </table>
</body>
</html>

<?php
$conn->close();
?>

