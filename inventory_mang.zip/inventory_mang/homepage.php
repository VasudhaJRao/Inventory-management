<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Management System</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            
        background: url('hom.jpg') no-repeat center center fixed;
            background-size: cover;
        }
        header {
            background-color:rebeccapurple;
            color: white;
            padding: 10px 0;
            text-align: center;
            
        }
        .container {
            width: 80%;
            margin: 8px auto;
        }
        .card {
            background:white;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin: 20px 0;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .card h2 {
            margin-top: 0;
        }
        .card a {
            display: inline-block;
            margin-top: 10px;
            padding: 10px 20px;
            background-color:lavender;
            color:black;
            text-decoration: none;
            border-radius: 5px;
        }
        .card a:hover {
            background-color:lavender;
        }
        
        .sidebar {
            height: 100%;
            width: 0;
            position: fixed;
            top: 0;
            left: 0;
            background-color: mediumpurple;
            overflow-x: hidden;
            padding-top: 20px;
            transition: 0.5s;
        }
        .sidebar a {
            padding: 10px 15px;
            text-decoration: none;
            font-size: 18px;
            color: white;
            display: block;
            transition: 0.3s;
            text-align: center;
        }
        .sidebar a:hover {
            color: #f1f1f1;
        }
        .sidebar .closebtn {
            position: absolute;
            top: 10px;
            right: 25px;
            font-size: 36px;
            margin-left: 50px;
        }
        .main {
            margin-left: 0;
            padding: 20px;
            transition: margin-left 0.5s;
        }
        .toggle-btn {
            font-size: 30px;
            cursor: pointer;
            position: fixed;
            top: 10px;
            left: 10px;
            color: white;
            z-index: 1;
        }
        .logout-btn {
            position: fixed;
            top: 10px;
            right: 10px;
            font-size: 18px;
            padding: 10px 20px;
            background-color: lavender;
            color: purple;
            border: none;
            cursor: pointer;
            z-index: 1;
        }
        .logout-btn:hover {
            background-color: white;
        }
        footer {
            background-color:mediumpurple;
            color: black;
            text-align: center;
            margin-right: 40%;
            padding: 10px 0;
            position: fixed;
            width: 120%;
            bottom: 0;
        }
    </style>
</head>
<body>

<header>
    <h1>Inventory Management System</h1>
</header>

<div class="container">
    <div class="card">
        <h2>View Inventory</h2>
        <p>Check the current stock levels of all items in your inventory.</p>
        <a href="inventory.php">Go to Inventory</a>
    </div>
    
    <div class="card">
        <h2>Add New Item</h2>
        <p>Add a new item to the inventory.</p>
        <a href="add_item.php">Add Item</a>
    </div>

    <div class="card">
        <h2>Generate Reports</h2>
        <p>Generate detailed reports about inventory status.</p>
        <a href="inventory_report.php">Generate Reports</a>
    </div>

    <div class="card">
        <h2>Orders</h2>
        <p>click here for order details.</p>
        <a href="orders.php">See Orders</a>
    </div>
</div>

<div class="sidebar" id="mySidebar">
    <a href="javascript:void(0)" class="closebtn" onclick="toggleSidebar()">×</a>
    <a href="homepage.php">Home</a>
    <a href="customer.php">Customer</a>
    <a href="delivery.php">Delivery</a>
    <a href="warehouse">Warehouses</a>
    <a href="provider.php">Provider</a> 
    <a href="customercare.php">Contact</a>
</div>

<div class="main" id="mainContent">
    <span class="toggle-btn" onclick="toggleSidebar()">☰</span>
    <form action="logout.php" method="post" style="display:inline;">
        <button type="submit" class="logout-btn">Logout</button>
    </form>
    

<script>
    function toggleSidebar() {
        var sidebar = document.getElementById("mySidebar");
        var mainContent = document.getElementById("mainContent");
        if (sidebar.style.width === "250px") {
            sidebar.style.width = "0";
            mainContent.style.marginLeft = "0";
        } else {
            sidebar.style.width = "250px";
            mainContent.style.marginLeft = "250px";
        }
    }
</script>

</body>
</html>

<footer>
    &copy; 2024 Inventory Management System
</footer>

</body>
</html>
