document.addEventListener('DOMContentLoaded', () => {
    updateReport();
});

async function updateReport() {
    const timePeriod = document.getElementById('time-period').value;
    const reportData = await getReportData(timePeriod);
    populateReportTable(reportData);
    generateGraph(reportData);
}

async function getReportData(timePeriod) {
    const response = await fetch(`fetch_inventory.php?period=${timePeriod}`);
    const data = await response.json();
    return data;
}

function populateReportTable(data) {
    const tbody = document.querySelector('#inventory-report tbody');
    tbody.innerHTML = '';
    data.forEach(item => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${item.itemName}</td>
            <td>${item.quantitySold}</td>
            <td>${item.stockRemaining}</td>
            <td>${item.reorderLevel}</td>
        `;
        tbody.appendChild(row);
    });
}

function generateGraph(data) {
    const ctx = document.getElementById('sales-graph').getContext('2d');
    const itemNames = data.map(item => item.itemName);
    const quantitiesSold = data.map(item => item.quantitySold);

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: itemNames,
            datasets: [{
                label: 'Quantity Sold',
                data: quantitiesSold,
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}
