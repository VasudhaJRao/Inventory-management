<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Page</title>
    
    <style>
        body {
    font-family:  Courier new,cursive;
    margin: 0;
    padding: 0;
    background-color: darkblue;
    background: url('inv.jpg') no-repeat center center fixed;
            background-size: cover;

}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
    
    color:lavender;
}

h1 {
    text-align: center;
    color: black;
    font-size: 3em;
    font-weight: bold;
    text-decoration-line: underline;

}

table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
    background-color: white;
    color: black;
    font-size: 1.3em;
}

th, td {
    border: 1px solid #ddd;
    padding: 8px;
    text-align: center;


}

th {
    background-color: lavender;
    color: black;
    font-weight: bold;
}



        
    </style>
</head>
<body>
    
    
    <div class="container">
        <h1>INVENTORY STOCK LEVELS</h1>
        <table id="inventory-table">
            <thead>
                <tr>
                    <th>Product_name</th>
                    <th>Price</th>
                    <th>max_stock</th>
                    <th>Quantity available</th>
                    <th>Quantity_sold</th>
                    <th>Quantity_remaining</th>
                    
                </tr>
            </thead>
            <tbody>
                <!-- Dynamic content will be populated here by JavaScript -->
            </tbody>
        </table>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            fetchInventoryData();
        });

        async function fetchInventoryData() {
            try {
                const response = await fetch('fetch_inven.php');
                const data = await response.json();
                populateInventoryTable(data);
            } catch (error) {
                console.error('Error fetching inventory data:', error);
            }
        }

        function populateInventoryTable(data) {
            const tbody = document.querySelector('#inventory-table tbody');
            tbody.innerHTML = '';
            data.forEach(item => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${item.product_name}</td>
                    <td>${item.Price}</td>
                    <td>${item.max_stock}</td>
                    <td>${item.quantity_available}</td>
                    <td>${item.quantity_sold}</td>
                    <td>${item.quantity_remaining}</td>
                    
                `;
                tbody.appendChild(row);
            });
        }


        
    </script>
</body>
</html>
